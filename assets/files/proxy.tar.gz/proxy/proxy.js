const express = require("express");
const { createProxyMiddleware } = require("http-proxy-middleware");
const { exec } = require("child_process");
const multer = require("multer");
const path = require("path");

const app = express();

/**
 * Configuration upload
 */
const upload = multer({
    dest: "uploads/"
});

/**
 * Endpoint upload vulnérable
 * Aucun contrôle de type, nom ou contenu
 */
app.post("/upload", upload.single("file"), (req, res) => {
    console.log("[UPLOAD]", req.file.filename);
    res.json({
        message: "File uploaded",
        file: req.file.filename
    });
});

/**
 * Endpoint exécution vulnérable
 * Injection via nom de fichier
 */
app.get("/run", (req, res) => {
    const file = req.query.file;

    console.log("[EXEC]", file);

    // ❌ VULNÉRABLE : aucune validation → RCE possible
    exec(`node uploads/${file}`, (err, stdout, stderr) => {
        if (err) {
            return res.json({ error: err.message });
        }
        res.json({ stdout, stderr });
    });
});

/**
 * Proxy vers Juice Shop
 */
app.use(
    "/",
    createProxyMiddleware({
        target: "http://localhost:3000",
        changeOrigin: true
    })
);

app.listen(3001, () => {
    console.log("Server running on http://localhost:3001");
});
